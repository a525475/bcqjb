const o="/icons/xiaoyugan.png";export{o as _};
